function setfilepermissions

    eval('!chmod g+rwx *.m')



end