

%%
show_gray(0, 1000) % full screen: 1, not full: 0, edge length in um
  
%%
show_gray(0, 600) 

%%
   
driftingsingratingseries2

%%
marching_bar_new 
  

%%
white_noise6