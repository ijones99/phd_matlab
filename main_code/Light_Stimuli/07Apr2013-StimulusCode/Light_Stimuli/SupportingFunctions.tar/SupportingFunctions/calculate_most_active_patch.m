function calculate_most_active_patch





end