
recTime = 10;
parapin(0)
hidens_startSaving(1,'bs-hpws03')

parapin(6)
for i=1:recTime
    pause(1);
    i
end

parapin(4)
hidens_stopSaving(1,'bs-hpws03')

parapin(0)
beep