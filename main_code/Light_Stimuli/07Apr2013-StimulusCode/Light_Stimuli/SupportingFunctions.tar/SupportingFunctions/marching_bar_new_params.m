function [params] = marching_bar_new_params
    params.valueX = 5;

end