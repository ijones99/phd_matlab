% ------------- DRIFTING GRATINGS ------------
% SETTINGS


flist{end+1} = ''


% ------------ MARCHING_BAR_NEW------------
% SETTINGS


flist{end+1} = ''



% ------------ WHITE_NOISE6 ------------ 
% SETTINGS



flist{end+1} = ''